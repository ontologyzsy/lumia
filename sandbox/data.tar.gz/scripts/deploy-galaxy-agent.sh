#!/usr/bin/env sh
mkdir -p /home/disk2/coresave
echo '/home/disk2/coresave/core.%e.%p.%t' | tee /proc/sys/kernel/core_pattern
chmod 777 -R /home/disk2/coresave

CGROUP_ROOT=/cgroups
df -h | grep $CGROUP_ROOT >/dev/null 2>&1
ret=$?
if [ $ret -eq 0 ]; then
    echo "cgroups exists ,skip"
else
    echo "init cgroups"
    mkdir -p $CGROUP_ROOT && mount -t tmpfs cgroup $CGROUP_ROOT
    mkdir -p $CGROUP_ROOT/cpu && mount -t cgroup -ocpu none $CGROUP_ROOT/cpu
    mkdir -p $CGROUP_ROOT/memory && mount -t cgroup -omemory none $CGROUP_ROOT/memory
    mkdir -p $CGROUP_ROOT/cpuacct && mount -t cgroup -ocpuacct none $CGROUP_ROOT/cpuacct
    mkdir -p $CGROUP_ROOT/freezer && mount -t cgroup -ofreezer none $CGROUP_ROOT/freezer
fi
/usr/sbin/adduser galaxy >/dev/null 2>&1
AGENT_IP=`hostname -i`
AGENT_HOME=/home/galaxy/agent
mkdir -p $AGENT_HOME/work_dir
mkdir -p $AGENT_HOME/gc_dir
mkdir -p $AGENT_HOME/log && cd $AGENT_HOME
wget -O tmp.tar.gz ftp://yq01-tera1.yq01.baidu.com/tmp/galaxy.tar.gz
tar -zxvf tmp.tar.gz
sed -i 's/--agent_mem_share=.*/--agent_mem_share=128849018880/' conf/galaxy.flag
echo "--agent_ip=$AGENT_IP" >> conf/galaxy.flag
df -h | grep ssd | awk '{print $6}' >> conf/mount_bind.template
df -h | grep disk | awk '{print $6}' >> conf/mount_bind.template
babysitter bin/galaxy-agent.conf stop >/dev/null 2>&1
sleep 1
babysitter bin/galaxy-agent.conf start
