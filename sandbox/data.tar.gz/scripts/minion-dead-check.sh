#!/usr/bin/env sh
cd ~ && ls -l
